def bubble_sort (arr1):
    n = len(arr1)
    #loop sesuai dengan banyaknya elemen arr
    for i in range (n):
        #lalu loop untuk membandingkan elemen arr dengan elemen selanjutnya (sekitarnya juga bisa sih)
        for j in range (0, n-i-1):
            #untuk membandingkan elemen jika elemen lebih besar dari elemen di sebelahnya maka akan dipindahkan
            if arr1[j] > arr1[j+1]:
                arr1[j], arr1[j+1] = arr1[j+1], arr1[j]
    return arr1

NIM_saya = [2, 5, 0, 7, 1, 2, 0, 7, 0, 8, 3]
print ("hasil bubble sort dari NIM Hadi Fauzan: ", bubble_sort(NIM_saya.copy()))