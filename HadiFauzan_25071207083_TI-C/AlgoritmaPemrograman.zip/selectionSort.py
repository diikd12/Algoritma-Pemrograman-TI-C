def selection_sort(arr):
    n = len(arr)
    #loop banyak elemen arr
    for i in range (n):
        #nyari nilai min dari elemen arr
        min = i
        for j in range (i+1, n):
            if arr[j] < arr[min]:
                min = j
        #menukar nilai min dengan elemen pertama
        arr[i], arr[min] = arr[min], arr[i]
    return arr

NIM_saya = [2, 5, 0, 7, 1, 2, 0, 7, 0, 8, 3]
print ("hasil selection sort dari NIM Hadi Fauzan: ", selection_sort(NIM_saya.copy()))